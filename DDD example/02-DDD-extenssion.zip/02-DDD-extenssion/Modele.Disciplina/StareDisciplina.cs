﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modele.Disciplina
{
    public enum StareDisciplina
    {
        Inscrieri,
        InDesfasurare,
        Incheiata
    }
}
